'use strict';

const express = require('express');
const { requireAuth } = require('../middleware/auth');
const {
  getBotGuild, getBotGuildChannels, getBotGuildRoles, hasManageGuild,
  postBotMessage, getChannelMessage, addBotReaction,
} = require('../services/discord');
const { getGuildConfig, setGuildConfig } = require('../../src/database/database');
const {
  listReactionRoles, addReactionRole, removeReactionRole,
  listTempRoles, addTempRole, removeTempRoleEntry,
} = require('../../src/modules/roles');
const { addAutoResponder, removeAutoResponder, listAutoResponders } = require('../../src/modules/autoresponders');
const { parseDuration, formatDuration } = require('../../src/utils/duration');
const { panelRow } = require('../../src/modules/tickets');

const router = express.Router();
router.use(requireAuth);

const LOG_TYPES = [
  ['messageDelete', 'Messages supprimés'],
  ['messageUpdate', 'Messages modifiés'],
  ['memberJoin', 'Arrivées de membres'],
  ['memberLeave', 'Départs de membres'],
  ['moderation', 'Actions de modération'],
  ['tickets', 'Tickets'],
  ['giveaways', 'Giveaways'],
  ['roles', 'Changements de rôles'],
  ['nickname', 'Changements de pseudo'],
  ['channels', 'Changements de salons'],
];

// ---------------------------------------------------------------------------
// GET /dashboard — liste des serveurs gérables par l'utilisateur
// ---------------------------------------------------------------------------
router.get('/', async (req, res) => {
  const manageable = (req.session.guilds || []).filter((g) => hasManageGuild(g.permissions));

  const guilds = await Promise.all(manageable.map(async (g) => {
    const botGuild = await getBotGuild(g.id);
    return {
      id: g.id,
      name: g.name,
      icon: g.icon ? `https://cdn.discordapp.com/icons/${g.id}/${g.icon}.png` : null,
      botPresent: !!botGuild,
      memberCount: botGuild?.approximate_member_count ?? null,
    };
  }));

  guilds.sort((a, b) => (b.botPresent - a.botPresent) || a.name.localeCompare(b.name));

  res.render('guilds', { user: req.session.user, guilds, inviteClientId: process.env.DISCORD_CLIENT_ID });
});

// ---------------------------------------------------------------------------
// Vérifie que l'utilisateur gère bien ce serveur et que le bot y est présent
// ---------------------------------------------------------------------------
async function loadGuildContext(req, res, next) {
  const { guildId } = req.params;
  const sessionGuild = (req.session.guilds || []).find((g) => g.id === guildId);

  if (!sessionGuild || !hasManageGuild(sessionGuild.permissions)) {
    return res.status(403).render('error', { message: "Vous n'avez pas la permission de gérer ce serveur." });
  }

  const botGuild = await getBotGuild(guildId);
  if (!botGuild) {
    return res.status(404).render('error', { message: "Le bot n'est pas présent sur ce serveur." });
  }

  const [channels, roles] = await Promise.all([
    getBotGuildChannels(guildId),
    getBotGuildRoles(guildId),
  ]);

  req.guildContext = {
    id: guildId,
    name: sessionGuild.name,
    textChannels: (channels || []).filter((c) => c.type === 0).sort((a, b) => a.position - b.position),
    voiceChannels: (channels || []).filter((c) => c.type === 2).sort((a, b) => a.position - b.position),
    categories: (channels || []).filter((c) => c.type === 4).sort((a, b) => a.position - b.position),
    roles: (roles || []).filter((r) => r.id !== guildId).sort((a, b) => b.position - a.position),
  };
  next();
}

// ---------------------------------------------------------------------------
// GET /dashboard/:guildId — page de configuration complète
// ---------------------------------------------------------------------------
router.get('/:guildId', loadGuildContext, (req, res) => {
  const config = getGuildConfig(req.params.guildId);
  res.render('guild', {
    guild: req.guildContext,
    config,
    logTypes: LOG_TYPES,
    saved: req.query.saved === '1',
    error: req.query.error || null,
    reactionRoles: listReactionRoles(req.params.guildId),
    tempRoles: listTempRoles(req.params.guildId),
    autoResponders: listAutoResponders(req.params.guildId),
    formatDuration,
  });
});

// ---------------------------------------------------------------------------
// POST handlers — un par catégorie de configuration
// ---------------------------------------------------------------------------
function redirectSaved(res, guildId, anchor) {
  res.redirect(`/dashboard/${guildId}?saved=1${anchor ? `#${anchor}` : ''}`);
}
function redirectError(res, guildId, message, anchor) {
  res.redirect(`/dashboard/${guildId}?error=${encodeURIComponent(message)}${anchor ? `#${anchor}` : ''}`);
}

router.post('/:guildId/automod', loadGuildContext, (req, res) => {
  const b = req.body;
  setGuildConfig(req.params.guildId, {
    automod: {
      enabled: b.enabled === 'on',
      action: b.action,
      antiSpam: b.antiSpam === 'on',
      antiFlood: b.antiFlood === 'on',
      antiInvite: b.antiInvite === 'on',
      antiLink: b.antiLink === 'on',
      antiMassMention: b.antiMassMention === 'on',
      antiCaps: b.antiCaps === 'on',
      maxMentions: Number(b.maxMentions) || 5,
      maxCapsPercent: Number(b.maxCapsPercent) || 70,
      spamMaxMessages: Number(b.spamMaxMessages) || 5,
      spamWindowMs: (Number(b.spamWindowSeconds) || 6) * 1000,
      bannedWords: (b.bannedWords || '').split(',').map((w) => w.trim()).filter(Boolean),
    },
  });
  redirectSaved(res, req.params.guildId, 'automod');
});

router.post('/:guildId/welcome', loadGuildContext, (req, res) => {
  const b = req.body;
  setGuildConfig(req.params.guildId, {
    welcome: {
      enabled: b.enabled === 'on',
      channelId: b.channelId || null,
      autoRoleId: b.autoRoleId || null,
      useEmbed: b.useEmbed === 'on',
      message: b.message || '',
    },
  });
  redirectSaved(res, req.params.guildId, 'welcome');
});

router.post('/:guildId/leave', loadGuildContext, (req, res) => {
  const b = req.body;
  setGuildConfig(req.params.guildId, {
    leave: {
      enabled: b.enabled === 'on',
      channelId: b.channelId || null,
      useEmbed: b.useEmbed === 'on',
      message: b.message || '',
    },
  });
  redirectSaved(res, req.params.guildId, 'leave');
});

router.post('/:guildId/logs', loadGuildContext, (req, res) => {
  const b = req.body;
  const logs = { channelId: b.channelId || null };
  for (const [key] of LOG_TYPES) logs[key] = b[key] === 'on';
  setGuildConfig(req.params.guildId, { logs });
  redirectSaved(res, req.params.guildId, 'logs');
});

router.post('/:guildId/tickets', loadGuildContext, (req, res) => {
  const b = req.body;
  setGuildConfig(req.params.guildId, {
    tickets: {
      enabled: b.enabled === 'on',
      categoryId: b.categoryId || null,
      staffRoleId: b.staffRoleId || null,
      transcriptChannelId: b.transcriptChannelId || null,
    },
  });
  redirectSaved(res, req.params.guildId, 'tickets');
});

// --- Publication du panneau de tickets depuis le site (mêmes options que /ticket-panel) ---
router.post('/:guildId/tickets/panel', loadGuildContext, async (req, res) => {
  const b = req.body;
  const config = getGuildConfig(req.params.guildId);
  if (!config.tickets.enabled) return redirectError(res, req.params.guildId, 'Activez les tickets avant de publier le panneau.', 'tickets');
  if (!b.panelChannelId) return redirectError(res, req.params.guildId, 'Choisissez un salon de publication.', 'tickets');

  const buttons = [];
  for (let i = 1; i <= 4; i += 1) {
    const label = b[`bouton${i}_label`];
    const emoji = b[`bouton${i}_emoji`];
    if (label) buttons.push({ label, emoji: emoji || undefined });
  }

  const color = b.couleur ? parseInt(b.couleur.replace('#', ''), 16) : 0x5865f2;
  const embed = {
    title: b.titre || '🎫 Support',
    description: b.description || "Cliquez sur le bouton ci-dessous pour ouvrir un ticket avec l'équipe.",
    color: Number.isNaN(color) ? 0x5865f2 : color,
  };
  const row = panelRow(buttons.length ? buttons : undefined).toJSON();

  try {
    await postBotMessage(b.panelChannelId, { embeds: [embed], components: [row] });
    redirectSaved(res, req.params.guildId, 'tickets');
  } catch (err) {
    console.error('[dashboard ticket panel]', err);
    redirectError(res, req.params.guildId, "Échec de la publication (permissions du bot sur ce salon ?).", 'tickets');
  }
});

router.post('/:guildId/leveling', loadGuildContext, (req, res) => {
  const b = req.body;
  setGuildConfig(req.params.guildId, {
    leveling: {
      enabled: b.enabled === 'on',
      xpPerMessage: [Number(b.xpMin) || 15, Number(b.xpMax) || 25],
      cooldownSeconds: Number(b.cooldownSeconds) || 60,
      levelUpChannelId: b.levelUpChannelId || null,
      autoLeaderboard: {
        enabled: b.autoLbEnabled === 'on',
        channelId: b.autoLbChannelId || null,
        intervalHours: Number(b.autoLbIntervalHours) || 168,
      },
    },
  });
  redirectSaved(res, req.params.guildId, 'leveling');
});

// --- Auto-rôles ---
router.post('/:guildId/autoroles', loadGuildContext, (req, res) => {
  const roleIds = [].concat(req.body.roleIds || []).filter(Boolean);
  setGuildConfig(req.params.guildId, { autoroles: { roleIds } });
  redirectSaved(res, req.params.guildId, 'autoroles');
});

// --- Rôles persistants (sticky) ---
router.post('/:guildId/stickyroles', loadGuildContext, (req, res) => {
  setGuildConfig(req.params.guildId, { stickyRoles: { enabled: req.body.enabled === 'on' } });
  redirectSaved(res, req.params.guildId, 'stickyroles');
});

// --- Rôle de tag ---
router.post('/:guildId/tagrole', loadGuildContext, (req, res) => {
  setGuildConfig(req.params.guildId, { tagRole: { roleId: req.body.roleId || null, label: req.body.label || 'Annonces' } });
  redirectSaved(res, req.params.guildId, 'tagrole');
});

// --- Auto-pseudo ---
router.post('/:guildId/autonick', loadGuildContext, (req, res) => {
  setGuildConfig(req.params.guildId, { autoNick: { enabled: req.body.enabled === 'on', template: req.body.template || '{username}' } });
  redirectSaved(res, req.params.guildId, 'autonick');
});

// --- Vocaux temporaires ---
router.post('/:guildId/voicehubs', loadGuildContext, (req, res) => {
  const b = req.body;
  setGuildConfig(req.params.guildId, {
    voiceHubs: {
      enabled: b.enabled === 'on',
      hubChannelId: b.hubChannelId || null,
      categoryId: b.categoryId || null,
      nameTemplate: b.nameTemplate || '🔊 Salon de {username}',
    },
  });
  redirectSaved(res, req.params.guildId, 'voicehubs');
});

// --- Économie ---
router.post('/:guildId/economy', loadGuildContext, (req, res) => {
  const b = req.body;
  setGuildConfig(req.params.guildId, {
    economy: {
      enabled: b.enabled === 'on',
      currencyName: b.currencyName || 'pièces',
      currencyEmoji: b.currencyEmoji || '🪙',
      dailyAmount: [Number(b.dailyMin) || 0, Number(b.dailyMax) || 0],
      weeklyAmount: [Number(b.weeklyMin) || 0, Number(b.weeklyMax) || 0],
      workAmount: [Number(b.workMin) || 0, Number(b.workMax) || 0],
      workCooldownMinutes: Number(b.workCooldownMinutes) || 60,
      autoLeaderboard: {
        enabled: b.autoLbEnabled === 'on',
        channelId: b.autoLbChannelId || null,
        intervalHours: Number(b.autoLbIntervalHours) || 168,
      },
    },
  });
  redirectSaved(res, req.params.guildId, 'economy');
});

// --- Giveaways (salon par défaut) ---
router.post('/:guildId/giveaways', loadGuildContext, (req, res) => {
  setGuildConfig(req.params.guildId, { giveaways: { defaultChannelId: req.body.defaultChannelId || null } });
  redirectSaved(res, req.params.guildId, 'giveaways');
});

// --- Rôles réaction : ajout (valide le message + ajoute la réaction du bot) ---
router.post('/:guildId/reactionroles/add', loadGuildContext, async (req, res) => {
  const { channelId, messageId, emoji, roleId } = req.body;
  if (!channelId || !messageId || !emoji || !roleId) {
    return redirectError(res, req.params.guildId, 'Tous les champs sont requis pour un rôle réaction.', 'reactionroles');
  }
  try {
    const message = await getChannelMessage(channelId, messageId);
    if (!message) throw new Error('Message introuvable');
    await addBotReaction(channelId, messageId, emoji);
    addReactionRole({ guild: { id: req.params.guildId }, channel: { id: channelId }, messageId, emoji, roleId });
    redirectSaved(res, req.params.guildId, 'reactionroles');
  } catch (err) {
    console.error('[dashboard reaction role]', err);
    redirectError(res, req.params.guildId, "Message introuvable dans ce salon, ou emoji invalide.", 'reactionroles');
  }
});

router.post('/:guildId/reactionroles/delete', loadGuildContext, (req, res) => {
  removeReactionRole(req.body.messageId, req.body.emoji);
  redirectSaved(res, req.params.guildId, 'reactionroles');
});

// --- Rôles temporaires ---
router.post('/:guildId/temproles/add', loadGuildContext, (req, res) => {
  const { userId, roleId, duree } = req.body;
  const durationMs = parseDuration(duree || '');
  if (!userId || !roleId || !durationMs) {
    return redirectError(res, req.params.guildId, 'ID de membre, rôle et durée valides (ex: 1h, 1d) sont requis.', 'temproles');
  }
  addTempRole({ guild: { id: req.params.guildId }, userId, roleId, moderatorId: req.session.user.id, durationMs });
  redirectSaved(res, req.params.guildId, 'temproles');
});

router.post('/:guildId/temproles/delete', loadGuildContext, (req, res) => {
  removeTempRoleEntry(req.params.guildId, req.body.userId, req.body.roleId);
  redirectSaved(res, req.params.guildId, 'temproles');
});

// --- Auto-répondeurs ---
router.post('/:guildId/autoresponders/add', loadGuildContext, (req, res) => {
  const { trigger, response } = req.body;
  if (!trigger || !response) return redirectError(res, req.params.guildId, 'Déclencheur et réponse sont requis.', 'autoresponders');
  addAutoResponder(req.params.guildId, trigger, response, req.body.exact === 'on');
  redirectSaved(res, req.params.guildId, 'autoresponders');
});

router.post('/:guildId/autoresponders/delete', loadGuildContext, (req, res) => {
  removeAutoResponder(req.params.guildId, Number(req.body.id));
  redirectSaved(res, req.params.guildId, 'autoresponders');
});

module.exports = router;
