'use strict';

const express = require('express');
const crypto = require('node:crypto');
const { exchangeCode, getCurrentUser, getUserGuilds } = require('../services/discord');

const router = express.Router();

router.get('/login', (req, res) => {
  const state = crypto.randomBytes(16).toString('hex');
  req.session.oauthState = state;

  const params = new URLSearchParams({
    client_id: process.env.DISCORD_CLIENT_ID,
    redirect_uri: process.env.DASHBOARD_CALLBACK_URL,
    response_type: 'code',
    scope: 'identify guilds',
    state,
    prompt: 'consent',
  });

  res.redirect(`https://discord.com/api/oauth2/authorize?${params.toString()}`);
});

router.get('/callback', async (req, res) => {
  const { code, state } = req.query;

  if (!code || !state || state !== req.session.oauthState) {
    return res.status(400).render('error', { message: 'Requête OAuth2 invalide ou expirée. Réessayez de vous connecter.' });
  }
  delete req.session.oauthState;

  try {
    const token = await exchangeCode(code);
    const [user, guilds] = await Promise.all([
      getCurrentUser(token.access_token),
      getUserGuilds(token.access_token),
    ]);

    req.session.user = user;
    req.session.accessToken = token.access_token;
    req.session.guilds = guilds;

    res.redirect('/dashboard');
  } catch (err) {
    console.error('[oauth callback]', err);
    res.status(500).render('error', { message: "Échec de la connexion à Discord. Vérifiez la configuration OAuth2 (.env) et réessayez." });
  }
});

router.get('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/'));
});

module.exports = router;
