'use strict';

require('dotenv').config();
const path = require('node:path');
const express = require('express');
const session = require('express-session');

const requiredVars = ['DISCORD_TOKEN', 'DISCORD_CLIENT_ID', 'DISCORD_CLIENT_SECRET', 'DASHBOARD_CALLBACK_URL', 'SESSION_SECRET'];
const missing = requiredVars.filter((v) => !process.env[v]);
if (missing.length) {
  console.error(`[DASHBOARD] Variables .env manquantes : ${missing.join(', ')}`);
  process.exit(1);
}

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 * 7 }, // 7 jours
}));

app.get('/', (req, res) => {
  if (req.session.user) return res.redirect('/dashboard');
  res.render('login');
});

app.use('/', require('./routes/auth'));
app.use('/dashboard', require('./routes/dashboard'));

app.use((req, res) => {
  res.status(404).render('error', { message: 'Page introuvable.' });
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('[DASHBOARD ERROR]', err);
  res.status(500).render('error', { message: 'Une erreur interne est survenue.' });
});

const PORT = process.env.DASHBOARD_PORT || 3000;
app.listen(PORT, () => console.log(`[DASHBOARD] En ligne sur http://localhost:${PORT}`));
