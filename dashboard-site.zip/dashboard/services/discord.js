'use strict';

const API = 'https://discord.com/api/v10';

async function exchangeCode(code) {
  const body = new URLSearchParams({
    client_id: process.env.DISCORD_CLIENT_ID,
    client_secret: process.env.DISCORD_CLIENT_SECRET,
    grant_type: 'authorization_code',
    code,
    redirect_uri: process.env.DASHBOARD_CALLBACK_URL,
  });

  const res = await fetch(`${API}/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  });
  if (!res.ok) throw new Error(`Échec de l'échange du code OAuth2 (${res.status})`);
  return res.json();
}

async function getCurrentUser(accessToken) {
  const res = await fetch(`${API}/users/@me`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) throw new Error(`Échec de récupération du profil (${res.status})`);
  return res.json();
}

async function getUserGuilds(accessToken) {
  const res = await fetch(`${API}/users/@me/guilds`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
  if (!res.ok) throw new Error(`Échec de récupération des serveurs (${res.status})`);
  return res.json();
}

// --- Appels authentifiés avec le token du BOT (lecture de données serveur) ---

async function botRequest(endpoint) {
  const res = await fetch(`${API}${endpoint}`, {
    headers: { Authorization: `Bot ${process.env.DISCORD_TOKEN}` },
  });
  if (!res.ok) return null;
  return res.json();
}

function getBotGuild(guildId) {
  return botRequest(`/guilds/${guildId}?with_counts=true`);
}

function getBotGuildChannels(guildId) {
  return botRequest(`/guilds/${guildId}/channels`);
}

function getBotGuildRoles(guildId) {
  return botRequest(`/guilds/${guildId}/roles`);
}

async function botRequestRaw(endpoint, { method = 'GET', body } = {}) {
  const res = await fetch(`https://discord.com/api/v10${endpoint}`, {
    method,
    headers: {
      Authorization: `Bot ${process.env.DISCORD_TOKEN}`,
      'Content-Type': 'application/json',
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`Discord API ${method} ${endpoint} -> ${res.status} ${text}`);
  }
  if (res.status === 204) return null;
  return res.json();
}

/** Publie un message (embeds/composants) dans un salon, via le token du bot. */
function postBotMessage(channelId, payload) {
  return botRequestRaw(`/channels/${channelId}/messages`, { method: 'POST', body: payload });
}

/** Récupère un message précis (utilisé pour valider un rôle réaction avant association). */
function getChannelMessage(channelId, messageId) {
  return botRequest(`/channels/${channelId}/messages/${messageId}`);
}

/** Ajoute la réaction du bot sur un message (nécessaire pour un rôle réaction). */
function addBotReaction(channelId, messageId, emoji) {
  return botRequestRaw(`/channels/${channelId}/messages/${messageId}/reactions/${encodeURIComponent(emoji)}/@me`, { method: 'PUT' });
}

const MANAGE_GUILD = 0x20n;

function hasManageGuild(permissionsField) {
  try {
    return (BigInt(permissionsField) & MANAGE_GUILD) === MANAGE_GUILD;
  } catch {
    return false;
  }
}

module.exports = {
  exchangeCode,
  getCurrentUser,
  getUserGuilds,
  getBotGuild,
  getBotGuildChannels,
  getBotGuildRoles,
  hasManageGuild,
  postBotMessage,
  getChannelMessage,
  addBotReaction,
};
